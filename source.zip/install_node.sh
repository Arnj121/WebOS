#!/bin/bash
sudo su
yum install nodejs -y
node -v
yum install git -y